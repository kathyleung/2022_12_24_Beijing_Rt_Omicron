function [out,dymRtDaily] = SEIR_memory(scaleRt,...
    contactMatrHome,childSuscept,genTime,seedSize,...
    totalPopulation,durExposed,dataMTR,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange)

maxTime = (tEnd-tStart)+1;
% SEIR model from Wu et al, PLOS Pathogens
numAgeGroup = length(totalPopulation);
% Intermediate variables
dSdt = zeros(1,numAgeGroup);
dEdt = zeros(numEstate,numAgeGroup);
dIdt = zeros(numIstate,numAgeGroup);
% Record variables
incidence = zeros(maxTime/dt,numAgeGroup);
% Duration of sub-E and sub-I states
subEduration = durExposed/numEstate;
durInfectious = 2*(genTime-durExposed)*numIstate/(numIstate+1);
subIduration = durInfectious/numIstate;

% Contact matrix
contactMatr = cell(1,maxTime);
iiMobility = zeros(maxTime,1);
ngmBeta = zeros(maxTime,1);
for iiMatr = 1:maxTime
    if iiMatr <= length(dataMTR)
        iiMobility(iiMatr,:) = repmat(dataMTR(iiMatr,1),1,1);
    else
        iiMobility(iiMatr,:) = repmat(mean(dataMTR((end-6):end,1)),1,1);
    end
end
iiMobility = movmean(iiMobility,5);
contactMatrOct = cell(maxTime,1);
for iiMatr = 1:maxTime
    if iiMatr <= dateChange-7
        contactMatrOct{iiMatr} = (1-exp(-iiMobility(iiMatr,1)))*scaleRt(1)*contactMatrHome;
    else
        if iiMatr > dateChange-7 &&  iiMatr <= dateChange+7
            iiScale = scaleRt(1)+(scaleRt(2)-scaleRt(1))/14*(iiMatr-dateChange+7);
            contactMatrOct{iiMatr} = (1-exp(-iiMobility(iiMatr,1)))*iiScale*contactMatrHome;
        else
            contactMatrOct{iiMatr} = (1-exp(-iiMobility(iiMatr,1)))*scaleRt(2)*contactMatrHome;
        end
    end
    contactMatr{iiMatr} = contactMatrOct{iiMatr}.*[...
        childSuscept,1,1;
        childSuscept,1,1;
        childSuscept,1,1;];
    [~,ngmDig] = eig(contactMatr{iiMatr}.*repmat(totalPopulation',1,numAgeGroup)*genTime); 
    ngmEig = ngmDig((1:numAgeGroup)+numAgeGroup*(0:(numAgeGroup-1)));
    ngmBeta(iiMatr,1) = max(ngmEig);
    contactMatr{iiMatr} = contactMatr{iiMatr};
    % recRt(iiMatr,1) = ngmBeta(iiMatr,1)*max(ngmEig);
end

% Initial conditions
% 1. State S
stateS = totalPopulation - seedSize/sum(totalPopulation)*totalPopulation;
% 2. State E
stateE = repmat(seedSize/numEstate/sum(totalPopulation)*totalPopulation,numEstate,1);
% 3. State I
stateI = zeros(numIstate,numAgeGroup);

for tt = 1:(maxTime/dt-1)
    tday = tt*dt;
    contactMatrWork = contactMatr{ceil(tday)};
    for ii = 1:numAgeGroup
        dSdt(ii) = - stateS(ii)*ngmBeta(ceil(tday),1)*...
            sum(contactMatrWork(ii,:).*sum(stateI));
    end
    % Exposed states
    for ii = 1:numEstate
        if ii == 1
            dEdt(ii,:) = - sum(dSdt,1) - stateE(ii,:)/subEduration;
        else
            dEdt(ii,:) = stateE(ii-1,:)/subEduration - stateE(ii,:)/subEduration;
        end
    end
    % Infectious states
    for ii = 1:numIstate
        if ii == 1
            dIdt(ii,:) = stateE(end,:)/subEduration - stateI(ii,:)/subIduration;
        else
            dIdt(ii,:) =  stateI(ii-1,:)/subIduration -  stateI(ii,:)/subIduration;
        end
    end
    % Update state variables
    stateS = stateS + dSdt*dt;
    stateE = stateE + dEdt*dt;
    stateI = stateI + dIdt*dt;
    % Update incidence record
    incidence(tt,:) = -sum(dSdt,1)*dt;

    dymRt(tt) = sum(incidence(tt,:),2)/sum(sum(stateI))*genTime/dt;
end
dymRtDaily = dymRt((1/dt/2):(1/dt):end)';

dailyInc = zeros(maxTime,1);
for tt = 1:maxTime
    dailyInc(tt,:) = sum(sum(incidence((tt-1)/dt+(1:1/dt),:)));
end

out = [(tStart:tEnd)',dailyInc,cumsum(dailyInc)];

end

