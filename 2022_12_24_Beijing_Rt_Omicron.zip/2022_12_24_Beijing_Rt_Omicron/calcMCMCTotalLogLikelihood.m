function out = calcMCMCTotalLogLikelihood(x0,...
    dataBeijing,genTimeData,prevData,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation)


scaleRt = x0(1:2);
genTime = x0(3);
seedSize = x0(4);
propReport = x0(5);
propAscertain = x0(6);

totalLogL = totalLogLikelihood(dataBeijing,genTimeData,prevData,...
    scaleRt,genTime,seedSize,propReport,propAscertain,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation);

out = totalLogL;

end

