
clear all;
rng('shuffle');

% 0. Date
dateZero = datenum('2022/10/31','yyyy/mm/dd');
dateChange = datenum('2022/11/18','yyyy/mm/dd')-dateZero;
dateEnd = datenum('2022/12/22','yyyy/mm/dd')-dateZero;

% 1. Contact pattern
% Define age groups
dataDir = 'data/';
countryText = 'China_subnational_Beijing';
totalPopulation = 21893095;
ageGroupDefRange = [-1,19,59,84];
% Age distribution
ageDistrTemp = readmatrix([dataDir,'age_distributions/',countryText,'_age_distribution_85.csv']);
totalPop = totalPopulation;
ageDistributionOneyear =  ageDistrTemp(:,2)/sum(ageDistrTemp(:,2));
% Contact matrix by setting
overallMatr = readmatrix([dataDir,'contact_matrices/',countryText,'_M_overall_contact_matrix_85.csv']);
[overallMatr,ageDistribution] = polymodContactMatrix(ageGroupDefRange,overallMatr,ageDistributionOneyear,totalPop);
contactMatr = overallMatr;
totalPopulation = totalPop*ageDistribution;
totalPopulationAgeBand = totalPopulation;

% 2. Load Beijing MTR data
bjMTRdata = readtable('data\2022_12_22_subway_beijing.xlsx');
% Moving average
bjMTRdata.date = datenum(bjMTRdata.date)-dateZero;
bjMTRdata.total = movmean(bjMTRdata.total,5);

% 3. Load Beijing local case data
cutoffDate = datenum('2022/11/30','yyyy/mm/dd')-dateZero;
localCase = readtable("data\2022_12_13_reported_case_beijing.xlsx");
localCase.date = datenum(localCase.date)-dateZero;
localCase = localCase(localCase.date<=datenum(cutoffDate),:);
localCase.num_local_case = localCase.num_new_confirmed_case_local;
dataBeijing = outerjoin(bjMTRdata(:,{'date','total'}),localCase(:,{'date','num_local_case'}),...
    'LeftKeys','date','RightKeys','date','MergeKeys',true);

% 4. Load Beijing prevalence data
prevData = readtable("data\2022_12_22_prevalence_beijing.xlsx");
prevData.date = datenum(prevData.date)-dateZero;

% 5. Load serial interval data
genTimeData = readtable('data\si_data_20200508.csv');     
genTimeData = genTimeData{:,3:4};

% Model parameters
scaleRt = [0.03,0.07];
genTime = 4.6;
seedSize = 100;
propReport = 0.1;
propAscertain = 0.8;

% Fixed child
childSuscept = 1;

% Fixed parameters
tStart = 1;
tEnd = dateEnd;
% incubation period
meanIncubation = 3.5;
stdIncubation = 3.9/5.2*meanIncubation;
shapeIncu = (stdIncubation*stdIncubation)/meanIncubation;
scaleIncu = meanIncubation/shapeIncu;
numDays = tEnd-tStart;
pdfIncubation = gamcdf(2:(numDays+1),shapeIncu,scaleIncu) - gamcdf(1:numDays,shapeIncu,scaleIncu); 
pdfIncubation = pdfIncubation(1:20)';
cdfIncubation = cumsum(pdfIncubation);
cdfIncubation(length(cdfIncubation)) = 1;

% Total population for transmission dynamics
totalPopulation = totalPopulationAgeBand;
numEstate = 1;
numIstate = 4;
numRstate = 4;
durExposed = 1;
dt = 0.1;

totalLogL = totalLogLikelihood(dataBeijing,genTimeData,prevData,...
    scaleRt,genTime,seedSize,propReport,propAscertain,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation);
disp(['Starting log likelihood: ',num2str(totalLogL)]);

% Test Likelihood function
x0 = [scaleRt,genTime,seedSize,propReport,propAscertain];
x0LowerBound = [0.001,0.001,genTime,0,0,0];
x0UpperBound = [1.100,1.100,genTime,3000,1,1];
disp(['Starting neg log likelihood: ',num2str(negTotalLogLikelihood(...
    x0,...
    dataBeijing,genTimeData,prevData,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation))]); 

% Point estimates from fmincon
redeffun = @(x)negTotalLogLikelihood(x,dataBeijing,genTimeData,prevData,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation);
options = optimoptions(@fmincon,'Display','iter','MaxFunEvals',30000);
if exist(strcat('mcmc_result/',countryText,'_mle.csv'),'file') == 2
    x0 = csvread(strcat('mcmc_result/',countryText,'_mle.csv'));
    xfmin = fmincon(redeffun,x0,[],[],[],[],x0LowerBound,x0UpperBound,[],options);
    write_matrix_new(xfmin,strcat('mcmc_result/',countryText,'_mle.csv'),'w',',','dec');
else
    xfmin = fmincon(redeffun,x0,[],[],[],[],x0LowerBound,x0UpperBound,[],options);
    write_matrix_new(xfmin,strcat('mcmc_result/',countryText,'_mle.csv'),'w',',','dec');
end
write_matrix_new(xfmin,strcat('mcmc_result/',countryText,'_mle.csv'),'w',',','dec');

disp(['MLE neg log likelihood: ',num2str(negTotalLogLikelihood(...
    xfmin,...
    dataBeijing,genTimeData,prevData,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation))]); 

% MCMC
mcSteps = 20000;
if exist(strcat('mcmc_result/',countryText,'_parameter_step.csv'),'file') == 2
    stepSize = csvread(strcat('mcmc_result/',countryText,'_parameter_step.csv'));
else
    stepSize = 0.05*xfmin;
end
out = mcmcParallel(countryText,mcSteps,...
    dataBeijing,genTimeData,prevData,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStart,tEnd,dateChange,pdfIncubation,...
    xfmin,stepSize,x0LowerBound,x0UpperBound);