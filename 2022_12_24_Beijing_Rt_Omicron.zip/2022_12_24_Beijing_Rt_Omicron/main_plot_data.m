
clear all;

% 1. data
dateZero = datenum('2022/10/31','yyyy/mm/dd');
dateChange = datenum('2022/11/18','yyyy/mm/dd')-dateZero;
dateEnd = datenum('2022/12/22','yyyy/mm/dd')-dateZero;

% 2. Load Beijing MTR data
bjMTRdata = readtable('data\2022_12_22_subway_beijing.xlsx');
% Moving average
bjMTRdata.date = datenum(bjMTRdata.date)-dateZero;
bjMTRdata{:,2:end} = bjMTRdata{:,2:end}*10^4;
% bjMTRdata.total = movmean(bjMTRdata.total,5);

% 3. Load Beijing local case data
cutoffDate = datenum('2022/11/30','yyyy/mm/dd')-dateZero;
localCase = readtable("data\2022_12_13_reported_case_beijing.xlsx");
localCase.date = datenum(localCase.date)-dateZero;
localCase = localCase(localCase.date<=datenum(cutoffDate),:);
localCase.num_local_case = localCase.num_new_confirmed_case_local;
dataBeijing = outerjoin(bjMTRdata(:,{'date','total'}),localCase(:,{'date','num_local_case'}),...
    'LeftKeys','date','RightKeys','date','MergeKeys',true);

% 4. Load Beijing prevalence data
prevData = readtable("data\2022_12_22_prevalence_beijing.xlsx");
prevData.date = datenum(prevData.date)-dateZero;
prevData.date = prevData.date + [...
    -0.3,+0.3,...
    -0.4,+0,+0.4,...
    -0.3,+0.3,...
    +0,...
    +0,...
    +0,...
    -0.3,+0.3,...
    +0,...
    -0.3,+0.3,...
    -0.3,+0.3,...
    -0.3,+0.3,...
    -0.3,+0.3,...
    +0]';

% Colors
colorMp = [
    204, 0,   0;
    0, 153,   76;
    255, 178, 102;
    51, 153, 255]/255;

clf;
figure(1)
subplot(3,1,1)
set(gcf,'defaultAxesColorOrder',[0,0,0;0,153/255,76/255]);
% Reported cases
hCase = bar([localCase.num_new_confirmed_case_local(1:dateChange),localCase.num_new_asym_case_local(1:dateChange)],'stacked');
set(hCase(1),"EdgeColor","none","FaceColor",colorMp(3,:),"FaceAlpha",0.7);
set(hCase(2),"EdgeColor","none","FaceColor",colorMp(4,:),"FaceAlpha",0.7);
xlim([0.5,dateEnd+8])
ylim([0,800]);
ylabel('Number of cases')

% Prevalence
yyaxis right
[phat,pci] = binofit(prevData.no_ever_positive,prevData.no_participants);
hPrev = errorbar(prevData.date,phat',(phat-pci(:,1))',(pci(:,2)-phat)','LineStyle','none');
ylabel({'% of reported to be','positive since Nov 1'});
ylim([0,0.8]);
set(hPrev,'Color',colorMp(2,:),'LineWidth',1,'Marker','o',...
    'MarkerSize',2,'MarkerFaceColor',colorMp(2,:),'CapSize',0);
set(gca,'box','off',...
    'YTick',0:0.1:1,'YTickLabel',{'0%','10%','20%','30%','40%','50%','60%','70%','80%'},...
    'XTick',1:7:(dateEnd+8),'XTickLabel',{'Nov 1','Nov 8','Nov 15','Nov 22','Nov 29','Dec 6','Dec 13','Dec 20','Dec 27'})
hold off
hLegend = legend([hCase(1),hCase(2),hPrev],...
    {'No. of reported symptomatic cases',...
    'No. of reported asymptomatic cases',...
    '% of positive participants'});
set(hLegend,'box','off','Location','Northwest')

% MTR
subplot(3,1,2)
hMTR = line(bjMTRdata.date,bjMTRdata.total,'LineWidth',1,'Color',colorMp(1,:));
hold on
hLineBJMTR = line(bjMTRdata.date,bjMTRdata.Total_Beijing_MTR,'LineWidth',1,'Color',colorMp(2,:));
hold on
hLineBTSubway = line(bjMTRdata.date,bjMTRdata.Total_Beijing_subway_limited,'LineWidth',1,'Color',colorMp(4,:));
xlim([0.5,dateEnd+8]);
ylim([0,10]*10^6);
ylabel('No. of passengers')
set(gca,'box','off',...
    'XTick',1:7:(dateEnd+8),'XTickLabel',{'Nov 1','Nov 8','Nov 15','Nov 22','Nov 29','Dec 6','Dec 13','Dec 20','Dec 27'});
hLegend = legend([hMTR,hLineBJMTR,hLineBTSubway],...
    {'Beijing subway passengers (22 lines)',...
    'BJ MTR passengers (5 lines)',...
    'BJ Subway Limited passengers (17 lines)'});
set(hLegend,'box','off','Location','NorthEast');

subplot(3,1,3)
hMTR = line(bjMTRdata.date,bjMTRdata.total/bjMTRdata.total(1),'LineWidth',1,'Color',colorMp(1,:));
hold on
hLineBJMTR = line(bjMTRdata.date,bjMTRdata.Total_Beijing_MTR/bjMTRdata.Total_Beijing_MTR(1),'LineWidth',1,'Color',colorMp(2,:));
hold on
hLineBTSubway = line(bjMTRdata.date,bjMTRdata.Total_Beijing_subway_limited/bjMTRdata.Total_Beijing_subway_limited(1),'LineWidth',1,'Color',colorMp(4,:));
xlim([0.5,dateEnd+8]);
ylim([0,1.2]);
ylabel({'No. of passengers','relative to that on Nov 1'})
set(gca,'box','off',...
    'XTick',1:7:(dateEnd+8),'XTickLabel',{'Nov 1','Nov 8','Nov 15','Nov 22','Nov 29','Dec 6','Dec 13','Dec 20','Dec 27'},...
    'YTick',0:0.2:1.2);
hLegend = legend([hMTR,hLineBJMTR,hLineBTSubway],...
    {'Beijing subway passengers (22 lines)',...
    'BJ MTR passengers (5 lines)',...
    'BJ Subway Limited passengers (17 lines)'});
set(hLegend,'box','off','Location','NorthEast');








