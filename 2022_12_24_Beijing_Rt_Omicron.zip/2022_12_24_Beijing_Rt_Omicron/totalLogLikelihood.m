function totalLogL = totalLogLikelihood(dataBeijing,genTimeData,prevData,...
    scaleRt,genTime,seedSize,propReport,propAscertain,...
    contactMatr,childSuscept,totalPopulation,durExposed,...
    numEstate,numIstate,dt,tStartArr,tEndArr,dateChange,pdfIncubation)

% 1. Log likelihood of generation time distribution
exactGenTimeLogL = sum(log(gampdf(genTimeData(genTimeData(:,1)==genTimeData(:,2),1),numIstate,genTime/numIstate)));
intervalGenTimeLogL = sum(log(...
    gamcdf(genTimeData(genTimeData(:,1)~=genTimeData(:,2),2),numIstate,genTime/numIstate)-...
    gamcdf(genTimeData(genTimeData(:,1)~=genTimeData(:,2),1),numIstate,genTime/numIstate)));

% 2. Log Likelihood of incidence
for iiWave = 1:length(tStartArr)
    tStart = tStartArr(iiWave);
    tEnd = tEndArr(iiWave);
    [dailyRec,~] = SEIR_memory(scaleRt,...
        contactMatr,childSuscept,genTime,seedSize(iiWave),...
        totalPopulation,durExposed,dataBeijing.total/dataBeijing.total(dataBeijing.date==1),...
        numEstate,numIstate,dt,tStart,tEnd,dateChange);
    dailyInc = dailyRec(:,[1,2]);
    dailyCumInc = dailyRec(:,[1,3]);
    % convolution
    dailyOnset = zeros(length(dailyInc)+length(pdfIncubation)-1,length(dailyInc(1,:))-1);
    for iiDay = 1:length(dailyInc(:,1))
        for iiAge = 1:(length(dailyInc(1,:))-1)
            dailyOnset(iiDay:(iiDay+length(pdfIncubation)-1),iiAge) = dailyOnset(iiDay:(iiDay+length(pdfIncubation)-1),iiAge)+...
                dailyInc(iiDay,iiAge+1)*pdfIncubation;
        end
    end
    % Incidence: Poisson likelihood
    obsOnset = sum(dailyOnset,2);
    obsOnset = [(dailyInc(1)-1+(1:(length(obsOnset))))',obsOnset];
    obsOnset = obsOnset(tStart:tEnd,:);
    obsOnset = obsOnset(ismember(obsOnset(:,1),dataBeijing.date(~isnan(dataBeijing.num_local_case))),:);
    onsetData = [dataBeijing.num_local_case(ismember(dataBeijing.date,obsOnset(:,1))),obsOnset(:,2)];
    onsetData = onsetData(5:(dateChange-7),:);
    onsetLogL(iiWave) = sum(log(binopdf(onsetData(:,1),round(onsetData(:,2)),propReport)));
    % Prevalence: Binomial likelihood
    pSens = propAscertain;
    prevaData = [prevData.no_ever_positive,prevData.no_participants,pSens*dailyCumInc(prevData.date,2)/sum(totalPopulation)];
    prevalenceLogL = log(binopdf(prevData.no_ever_positive,prevData.no_participants,pSens*dailyCumInc(prevData.date,2)/sum(totalPopulation)));
end

onsetLogL(onsetLogL==-Inf) = -1e9;
prevalenceLogL(prevalenceLogL==-Inf) = -1e9;
totalLogL = exactGenTimeLogL+intervalGenTimeLogL+sum(sum(onsetLogL))+sum(sum(prevalenceLogL));

end

